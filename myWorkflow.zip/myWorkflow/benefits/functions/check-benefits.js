// Ths Lambda function first receives the event from onboarding bounded context and then log to console.
// Then this also triggers to execute a step functon with some parameters which will put an event back to Benefits Event Bus whch wll eventually go back to first bounded context.

const AWS = require('aws-sdk')

exports.handler = async (event) => {
    console.log('Received from Onboarding');
    console.log(JSON.stringify(event));

    const eventbridge = new AWS.EventBridge();
    const params = {
        Entries: [ 
            {
              Detail: JSON.stringify(event.detail),
              DetailType: 'BenefitsRevertPayload',
              EventBusName: 'ItsBenefitsContextEventBus',
              Source: 'ItsBenefitsWorkflow',
            },
          ]
      }
      const result = await eventbridge.putEvents(params).promise()
      console.log(JSON.stringify(params));
      console.log(result);
    return;
}