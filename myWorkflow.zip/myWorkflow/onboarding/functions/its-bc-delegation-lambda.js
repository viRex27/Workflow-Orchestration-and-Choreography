// This is a Lambda function to generate a new delegationId and update the record in the DynamoDb with taskToken.
// Then this lambda puts the event in the EventBus of First bounded Context (Onboarding Context Event Bus)

const AWS = require('aws-sdk')
const documentClient = new AWS.DynamoDB.DocumentClient();

const {v4: uuid} = require('uuid');
exports.handler = async (event,context,callback) => {
    console.log('Received Event');
    console.log(JSON.stringify(event));
    console.log(JSON.stringify(context));
    const delegationId = uuid();
   
    // creating payload for event to be sent to event bus
    const addedEvent = {
        "payload": event.payload,
        "delegationId": delegationId,
        "status": "STARTED"
    }
    console.log(JSON.stringify(event.token));
    
    const dbParam = {
        TableName: process.env.DatabaseTable,
        Key: {
            "id": event.payload.traceId
        },
        UpdateExpression: "SET #delegation = :value",
        ExpressionAttributeNames: {
           "#delegation": "delegations"
        },
        ExpressionAttributeValues: {
          ":value" : {}
        }
    };

    //Updating DynamoDB and adding empty object for delegations
    const data1 = await documentClient.update(dbParam).promise()

    //Updating DynamoDB and adding delegations
    const dbParams = {
        TableName: process.env.DatabaseTable,
        Key: {
            "id": event.payload.traceId
        },
        UpdateExpression: "SET delegations.#delegationIdS = :delegation",
        ExpressionAttributeNames: {
           "#delegationIdS": delegationId
        },
        ExpressionAttributeValues: {
          ":delegation": {
              "status":"STARTED",
              "task" : {
                "id" : event.payload.traceId,
                "name" : "OnboardingEvent",
                "taskToken" : event.token
              }
          }
        }
    };
    console.log(JSON.stringify(dbParams));

    // Updating DynamoDB with delegation
    const data = await documentClient.update(dbParams).promise()
    console.log(data);

    const eventbridge = new AWS.EventBridge();
    const params = {
        Entries: [ 
            {
              Detail: JSON.stringify(addedEvent),
              DetailType: 'BenefitAwardsCheckPayload',
              EventBusName: 'ItsOnBoardingContextEventBus',
              Source: 'ItsOnBoardingWorkflow',
            },
          ]
      }

    // Putting event to Onboardng Context event bus
      const result = await eventbridge.putEvents(params).promise()
      console.log(JSON.stringify(params));
      console.log(result);

}